'use strict';
/**
 * DICOM Modality Worklist (PS3.4 Annex K) — pembentukan dataset & pencocokan kunci C-FIND.
 * Atribut mengikuti IHE Radiology Scheduled Workflow (SWF).
 */
const db = require('../lib/db');
const config = require('../config');
const { nowLocal, addDays, toDicomDate, toDicomTime, toDicomName, toDicomPhysician } = require('../lib/util');

const CODING_LOINC = 'LN';
const CODING_LOCAL = '99RSHANAU';

// Grup modalitas yang dianggap setara saat mencocokkan (alat CR sering dijadwalkan sebagai DX & sebaliknya)
const EQUIV = { CR: ['CR', 'DX'], DX: ['DX', 'CR'] };

const str = (v) => {
  if (Array.isArray(v)) v = v[0];
  if (v === undefined || v === null) return '';
  if (typeof v === 'object') return String(v.Alphabetic ?? '').trim(); // PN ternaturalisasi
  return String(v).trim();
};
const isWildAll = (v) => !v || /^\*+$/.test(v);
const wildToLike = (v) => v.replace(/[%_]/g, '\\$&').replace(/\*/g, '%').replace(/\?/g, '_');

/** Ambil kunci pencarian dari dataset C-FIND (naturalized dcmjs). */
function extractQuery(ds) {
  const spsSeq = ds.ScheduledProcedureStepSequence;
  const sps = (Array.isArray(spsSeq) ? spsSeq[0] : spsSeq) || {};
  return {
    modality: str(sps.Modality),
    stationAe: str(sps.ScheduledStationAETitle),
    date: str(sps.ScheduledProcedureStepStartDate),
    patientId: str(ds.PatientID),
    accession: str(ds.AccessionNumber),
    patientName: str(ds.PatientName).replace(/\^+$/, ''),
    studyUid: str(ds.StudyInstanceUID),
    rpId: str(ds.RequestedProcedureID),
  };
}

function parseDateRange(v) {
  if (isWildAll(v)) return null;
  const m = v.match(/^(\d{8})?(-)?(\d{8})?$/);
  if (!m) return null;
  const fmt = (s) => `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
  if (!m[2]) return { from: fmt(m[1]), to: fmt(m[1]) };
  return { from: m[1] ? fmt(m[1]) : null, to: m[3] ? fmt(m[3]) : null };
}

/** Cari order yang cocok untuk C-FIND. callingStation = baris ris_modalities milik AE pemanggil (boleh null). */
async function findOrders(query, callingStation, stationsByAe = new Map()) {
  const where = ["o.status IN ('SCHEDULED','IN_PROGRESS')"];
  const p = [];

  const range = parseDateRange(query.date);
  if (range) {
    if (range.from) { where.push('o.scheduled_at >= ?'); p.push(range.from + ' 00:00:00'); }
    if (range.to) { where.push('o.scheduled_at <= ?'); p.push(range.to + ' 23:59:59'); }
  } else {
    const today = nowLocal().date;
    where.push('o.scheduled_at >= ?'); p.push(addDays(today, -(config.dicom.defaultDays - 1)) + ' 00:00:00');
    where.push('o.scheduled_at <= ?'); p.push(today + ' 23:59:59');
  }

  if (!isWildAll(query.modality)) {
    const mods = EQUIV[query.modality] || [query.modality];
    where.push(`o.modality IN (${mods.map(() => '?').join(',')})`); p.push(...mods);
  }
  // Filter stasiun: AE yang diminta di kunci SPS, atau (default) AE pemanggil.
  // Order tanpa AE tujuan ikut tampil di semua alat bermodalitas sama.
  const station = !isWildAll(query.stationAe)
    ? stationsByAe.get(query.stationAe) || { ae_title: query.stationAe, modality: null }
    : config.dicom.filterByCallingAe ? callingStation : null;
  if (station) {
    if (station.modality) {
      const mods = EQUIV[station.modality] || [station.modality];
      where.push(`(o.station_ae = ? OR ((o.station_ae IS NULL OR o.station_ae = '') AND o.modality IN (${mods.map(() => '?').join(',')})))`);
      p.push(station.ae_title, ...mods);
    } else {
      where.push("(o.station_ae = ? OR o.station_ae IS NULL OR o.station_ae = '')"); p.push(station.ae_title);
    }
  }
  for (const [val, col] of [[query.patientId, 'o.no_rkm_medis'], [query.accession, 'o.accession_number'], [query.studyUid, 'o.study_instance_uid'], [query.rpId, 'o.requested_procedure_id']]) {
    if (isWildAll(val)) continue;
    if (/[*?]/.test(val)) { where.push(`${col} LIKE ?`); p.push(wildToLike(val)); }
    else { where.push(`${col} = ?`); p.push(val); }
  }
  if (!isWildAll(query.patientName)) {
    where.push('o.patient_name LIKE ?');
    p.push(/[*?]/.test(query.patientName) ? wildToLike(query.patientName.replace(/\^/g, ' ')) : `%${query.patientName.replace(/\^/g, ' ')}%`);
  }

  return db.risQuery(
    `SELECT o.*, m.loinc_code, m.loinc_display, m.body_part, m.protocol_code, m.protocol_meaning,
            st.name AS station_name_full, st.station_name, st.room
       FROM ris_orders o
       LEFT JOIN ris_procedure_map m ON m.kd_jenis_prw = o.kd_jenis_prw
       LEFT JOIN ris_modalities st ON st.ae_title = o.station_ae
      WHERE ${where.join(' AND ')}
      ORDER BY (o.priority='STAT') DESC, o.scheduled_at LIMIT 500`,
    p
  );
}

/** Dataset MWL lengkap untuk satu order. */
function buildItem(o) {
  const procCode = o.loinc_code
    ? { CodeValue: o.loinc_code, CodingSchemeDesignator: CODING_LOINC, CodeMeaning: (o.loinc_display || o.procedure_name).slice(0, 64) }
    : { CodeValue: o.kd_jenis_prw, CodingSchemeDesignator: CODING_LOCAL, CodeMeaning: o.procedure_name.slice(0, 64) };
  const protocol = {
    CodeValue: o.protocol_code || o.kd_jenis_prw,
    CodingSchemeDesignator: CODING_LOCAL,
    CodeMeaning: (o.protocol_meaning || o.procedure_name).slice(0, 64),
  };
  const referring = toDicomPhysician(o.referring_name || '');
  return {
    SpecificCharacterSet: 'ISO_IR 100',
    AccessionNumber: o.accession_number,
    ReferringPhysicianName: referring,
    PatientName: toDicomName(o.patient_name, config.dicom.nameUppercase),
    PatientID: o.no_rkm_medis,
    IssuerOfPatientID: config.hospital.code,
    PatientBirthDate: toDicomDate(o.patient_birthdate),
    PatientSex: o.patient_sex || 'O',
    OtherPatientIDsSequence: o.patient_nik ? [{ PatientID: o.patient_nik, IssuerOfPatientID: 'NIK', TypeOfPatientID: 'TEXT' }] : [],
    AdmissionID: o.no_rawat,
    CurrentPatientLocation: (o.location || '').slice(0, 64),
    StudyInstanceUID: o.study_instance_uid,
    RequestingPhysician: referring,
    RequestedProcedureDescription: o.procedure_name.slice(0, 64),
    RequestedProcedureCodeSequence: [procCode],
    RequestedProcedureID: o.requested_procedure_id,
    RequestedProcedurePriority: o.priority === 'STAT' ? 'STAT' : 'ROUTINE',
    ReasonForTheRequestedProcedure: (o.diagnosis || '').slice(0, 64),
    MedicalAlerts: (o.clinical_info || '').slice(0, 64),
    ScheduledProcedureStepSequence: [
      {
        Modality: o.modality,
        ScheduledStationAETitle: o.station_ae || '',
        ScheduledStationName: o.station_name || '',
        ScheduledProcedureStepLocation: (o.room || '').slice(0, 16),
        ScheduledProcedureStepStartDate: toDicomDate(o.scheduled_at),
        ScheduledProcedureStepStartTime: toDicomTime(o.scheduled_at),
        ScheduledPerformingPhysicianName: '',
        ScheduledProcedureStepDescription: o.procedure_name.slice(0, 64),
        ScheduledProtocolCodeSequence: [protocol],
        ScheduledProcedureStepID: o.sps_id,
        ScheduledProcedureStepStatus: o.status === 'IN_PROGRESS' ? 'STARTED' : 'SCHEDULED',
      },
    ],
  };
}

const isSeq = (v) => Array.isArray(v) && v.length > 0 && v[0] && typeof v[0] === 'object' && !('Alphabetic' in v[0]);

/**
 * Proyeksi: kembalikan hanya atribut yang diminta SCU (PS3.4 C.4.1.2.3).
 * Kunci sekuens kosong / tanpa item -> seluruh item dikembalikan.
 */
function project(template, full) {
  const out = { SpecificCharacterSet: full.SpecificCharacterSet };
  for (const k of Object.keys(template || {})) {
    if (k.startsWith('_') || k === 'SpecificCharacterSet') continue;
    const t = template[k];
    const v = full[k];
    if (isSeq(v)) {
      const tItem = Array.isArray(t) && t[0] && typeof t[0] === 'object' ? t[0] : null;
      out[k] = tItem && Object.keys(tItem).filter((x) => !x.startsWith('_')).length
        ? v.map((it) => { const r = project(tItem, it); delete r.SpecificCharacterSet; return r; })
        : v;
    } else if (v !== undefined) {
      out[k] = v;
    } else {
      out[k] = Array.isArray(t) ? [] : ''; // atribut yang tidak kami miliki -> nilai kosong
    }
  }
  return out;
}

module.exports = { extractQuery, parseDateRange, findOrders, buildItem, project };
