'use strict';
/**
 * Sinkronisasi order: SIMRS Khanza (permintaan_radiologi) -> RIS (ris_orders).
 * Setiap item pemeriksaan pada satu noorder menjadi satu Requested Procedure
 * dengan Accession Number & Study Instance UID sendiri.
 */
const db = require('../lib/db');
const config = require('../config');
const log = require('../lib/logger')('sync');
const khanza = require('../khanza/khanzaRepo');
const orders = require('./orderService');
const mapping = require('./mappingService');
const { nowLocal, addDays, generateUid, isZeroDate } = require('../lib/util');

let running = false;
let lastRun = null;
let lastError = null;
let lastCount = 0;

async function syncOnce() {
  if (running) return { skipped: true };
  running = true;
  try {
    const since = addDays(nowLocal().date, -config.sync.lookbackDays);
    const rows = await khanza.listOrdersSince(since);
    const existing = await db.risQuery(
      'SELECT id, noorder, kd_jenis_prw, status FROM ris_orders WHERE requested_at >= ?', [since + ' 00:00:00']
    );
    const key = (a, b) => `${a}|${b}`;
    const have = new Map(existing.map((e) => [key(e.noorder, e.kd_jenis_prw), e]));
    const seen = new Set();
    let created = 0;

    for (const r of rows) {
      const k = key(r.noorder, r.kd_jenis_prw);
      seen.add(k);
      if (have.has(k)) continue;
      // Duplikasi di luar jendela lookback (mis. order lama yang diedit) - cek langsung
      const dup = await db.risOne('SELECT id FROM ris_orders WHERE noorder=? AND kd_jenis_prw=?', [r.noorder, r.kd_jenis_prw]);
      if (dup) continue;
      await createOrder(r);
      created++;
    }

    // Order yang dihapus/dibatalkan di Khanza dan belum dikerjakan -> CANCELLED
    for (const e of existing) {
      if (!seen.has(key(e.noorder, e.kd_jenis_prw)) && e.status === 'SCHEDULED') {
        await orders.setStatus(e.id, 'CANCELLED', { detail: 'Permintaan tidak ditemukan lagi di SIMRS Khanza' });
        log.info(`Order ${e.noorder}/${e.kd_jenis_prw} dibatalkan (hilang dari Khanza)`);
      }
    }
    lastRun = nowLocal().dt; lastError = null; lastCount = created;
    if (created) log.info(`${created} order baru dari Khanza`);
    return { created, scanned: rows.length };
  } catch (e) {
    lastError = e.message;
    log.error('Sinkron gagal', e);
    throw e;
  } finally {
    running = false;
  }
}

async function createOrder(r) {
  const map = await mapping.getMap(r.kd_jenis_prw);
  const modality = (map && map.modality) || mapping.guessModality(r.nm_perawatan);
  const station = await mapping.pickStation(map, modality);
  const accession = await orders.nextAccession();
  const requestedAt = `${r.tgl_permintaan} ${r.jam_permintaan || '00:00:00'}`;
  const isStat = /CITO|STAT|SEGERA/i.test(`${r.informasi_tambahan || ''} ${r.diagnosa_klinis || ''}`) || r.kd_poli === 'IGDK';
  const location = r.status_rawat === 'ranap' ? r.nm_bangsal || 'Rawat Inap' : r.nm_poli || 'Rawat Jalan';

  const row = {
    noorder: r.noorder,
    kd_jenis_prw: r.kd_jenis_prw,
    no_rawat: r.no_rawat,
    no_rkm_medis: r.no_rkm_medis,
    patient_name: r.nm_pasien,
    patient_sex: r.jk === 'P' ? 'F' : r.jk === 'L' ? 'M' : 'O',
    patient_birthdate: isZeroDate(r.tgl_lahir) ? null : r.tgl_lahir,
    patient_nik: r.no_ktp || null,
    patient_address: r.alamat || null,
    status_rawat: r.status_rawat,
    location,
    penjamin: r.png_jawab || null,
    procedure_name: r.nm_perawatan,
    modality,
    station_ae: station,
    accession_number: accession,
    requested_procedure_id: accession,
    sps_id: accession + '1',
    study_instance_uid: generateUid(),
    referring_kd_dokter: r.dokter_perujuk || null,
    referring_name: r.nm_perujuk || null,
    clinical_info: r.informasi_tambahan || null,
    diagnosis: r.diagnosa_klinis || null,
    priority: isStat ? 'STAT' : 'ROUTINE',
    requested_at: requestedAt,
    scheduled_at: requestedAt,
  };
  const cols = Object.keys(row);
  const [res] = await db.ris.query(
    `INSERT INTO ris_orders (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`,
    cols.map((c) => row[c])
  );
  await orders.addEvent(res.insertId, 'CREATED', {
    source: 'Khanza', noorder: r.noorder, accession, modality, station_ae: station, mapped: !!map,
  });
  if (!map) await orders.addEvent(res.insertId, 'WARNING', `Jenis pemeriksaan ${r.kd_jenis_prw} belum dipetakan; modalitas ditebak ${modality}`);
  const order = await orders.getById(res.insertId);
  orders.bus.emit('order.created', order);
  return order;
}

let timer = null;
function start() {
  const tick = () => syncOnce().catch(() => {}).finally(() => { timer = setTimeout(tick, config.sync.intervalMs); });
  tick();
  log.info(`Sinkron Khanza aktif setiap ${config.sync.intervalMs / 1000} detik (lookback ${config.sync.lookbackDays} hari)`);
}
const stop = () => timer && clearTimeout(timer);
const status = () => ({ running, lastRun, lastError, lastCount });

module.exports = { syncOnce, start, stop, status, createOrder };
