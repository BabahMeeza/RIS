'use strict';
const db = require('../lib/db');
const khanza = require('../khanza/khanzaRepo');

const MODALITIES = {
  CR: 'Computed Radiography', DX: 'Digital Radiography', CT: 'Computed Tomography', MR: 'Magnetic Resonance',
  US: 'Ultrasound', MG: 'Mammography', RF: 'Radio Fluoroscopy', XA: 'X-Ray Angiography', NM: 'Nuclear Medicine',
  PT: 'PET', OT: 'Other', IO: 'Intra-oral Radiography', PX: 'Panoramic X-Ray', BMD: 'Bone Densitometry',
};

/** Tebak modalitas dari nama pemeriksaan bila belum dipetakan (agar order tetap masuk worklist). */
function guessModality(name = '') {
  const n = name.toUpperCase();
  if (/\b(CT|CT-SCAN|CTSCAN|MSCT)\b|CT SCAN/.test(n)) return 'CT';
  if (/\bMRI?\b/.test(n)) return 'MR';
  if (/USG|ULTRASO|DOPPLER|ECHO/.test(n)) return 'US';
  if (/MAMMO/.test(n)) return 'MG';
  if (/PANORAMI|OPG/.test(n)) return 'PX';
  if (/DENTAL|PERIAPIKAL/.test(n)) return 'IO';
  if (/FLUORO|BNO.?IVP|IVP|COLON IN LOOP|OMD|HSG|ESOFAGOGRAFI|URETROGRAFI/.test(n)) return 'RF';
  return 'DX';
}

const getMap = (kd) => db.risOne('SELECT * FROM ris_procedure_map WHERE kd_jenis_prw=?', [kd]);

/** Gabungan master Khanza + pemetaan RIS, untuk halaman pemetaan. */
async function listMerged() {
  const [procs, maps] = await Promise.all([khanza.listProcedures(), db.risQuery('SELECT * FROM ris_procedure_map')]);
  const byKd = new Map(maps.map((m) => [m.kd_jenis_prw, m]));
  const rows = procs.map((p) => ({ ...p, mapped: byKd.has(p.kd_jenis_prw), map: byKd.get(p.kd_jenis_prw) || null }));
  for (const m of maps) if (!procs.find((p) => p.kd_jenis_prw === m.kd_jenis_prw)) rows.push({ kd_jenis_prw: m.kd_jenis_prw, nm_perawatan: m.nm_perawatan, mapped: true, orphan: true, map: m });
  return rows;
}

const FIELDS = ['nm_perawatan', 'modality', 'default_ae_title', 'body_part', 'loinc_code', 'loinc_display', 'kode_nasional',
  'snomed_bodysite_code', 'snomed_bodysite_display', 'radlex_code', 'radlex_display', 'laterality',
  'protocol_code', 'protocol_meaning', 'contrast', 'active'];

async function saveMap(kd, data) {
  if (!data.modality || !MODALITIES[data.modality]) throw new Error('Modalitas DICOM wajib diisi & valid');
  if (data.loinc_code && !/^\d{1,7}-\d$/.test(data.loinc_code)) throw new Error('Format kode LOINC tidak valid (contoh 24648-8)');
  if (data.snomed_bodysite_code && !/^\d{6,18}$/.test(data.snomed_bodysite_code)) throw new Error('Kode SNOMED CT harus angka (SCTID)');
  const row = {};
  for (const f of FIELDS) row[f] = data[f] === '' || data[f] === undefined ? null : data[f];
  row.contrast = data.contrast ? 1 : 0;
  row.active = data.active === undefined ? 1 : data.active ? 1 : 0;
  const cols = ['kd_jenis_prw', ...FIELDS];
  await db.risQuery(
    `INSERT INTO ris_procedure_map (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})
     ON DUPLICATE KEY UPDATE ${FIELDS.map((f) => `${f}=VALUES(${f})`).join(', ')}`,
    [kd, ...FIELDS.map((f) => row[f])]
  );
  return getMap(kd);
}

/** Pilih AE Title alat untuk sebuah order: default pemetaan, atau satu-satunya alat aktif bermodalitas sama. */
async function pickStation(map, modality) {
  if (map && map.default_ae_title) return map.default_ae_title;
  const group = modality === 'CR' || modality === 'DX' ? ['CR', 'DX'] : [modality];
  const rows = await db.risQuery(`SELECT ae_title FROM ris_modalities WHERE active=1 AND modality IN (${group.map(() => '?').join(',')})`, group);
  return rows.length === 1 ? rows[0].ae_title : null; // >1 alat: biarkan kosong, semua alat modalitas tsb melihatnya
}

module.exports = { MODALITIES, guessModality, getMap, listMerged, saveMap, pickStation };
