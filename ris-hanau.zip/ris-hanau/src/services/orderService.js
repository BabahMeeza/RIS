'use strict';
const EventEmitter = require('events');
const db = require('../lib/db');
const { nowLocal } = require('../lib/util');
const config = require('../config');

/** Event bus antar-modul: 'order.created', 'order.status', 'order.cancelled', 'report.verified', 'images.available' */
const bus = new EventEmitter();
bus.setMaxListeners(50);

// Urutan alur kerja. Status hanya bergerak maju (kecuali pembatalan / koreksi manual).
const RANK = { SCHEDULED: 1, IN_PROGRESS: 2, COMPLETED: 3, REPORTED: 4, VERIFIED: 5 };
const TERMINAL = ['CANCELLED', 'DISCONTINUED'];
const ALL_STATUS = ['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'DISCONTINUED', 'CANCELLED', 'REPORTED', 'VERIFIED'];

async function addEvent(orderId, event, detail = null, actor = 'system') {
  await db.risQuery('INSERT INTO ris_order_events (order_id, event, detail, actor) VALUES (?,?,?,?)', [
    orderId, event, detail == null ? null : typeof detail === 'string' ? detail : JSON.stringify(detail), actor,
  ]);
}

const getById = (id) => db.risOne('SELECT * FROM ris_orders WHERE id=?', [id]);
const getByAccession = (acc) => db.risOne('SELECT * FROM ris_orders WHERE accession_number=?', [acc]);
const getByStudyUid = (uid) => db.risOne('SELECT * FROM ris_orders WHERE study_instance_uid=?', [uid]);

/** Accession Number: PREFIX + yymmdd + nomor urut 4 digit per hari (maks 16 karakter, sesuai DICOM SH & DICOM Router Satu Sehat). */
async function nextAccession() {
  const ymd = nowLocal().dicomDate.slice(2);
  const key = 'ACC' + ymd;
  const [res] = await db.ris.query(
    'INSERT INTO ris_counters (k, v) VALUES (?, LAST_INSERT_ID(1)) ON DUPLICATE KEY UPDATE v = LAST_INSERT_ID(v + 1)',
    [key]
  );
  const seq = res.insertId || (await db.risOne('SELECT v FROM ris_counters WHERE k=?', [key])).v;
  const acc = `${config.sync.accessionPrefix}${ymd}${String(seq).padStart(4, '0')}`;
  if (acc.length > 16) throw new Error(`Accession ${acc} melebihi 16 karakter, perpendek ACCESSION_PREFIX`);
  return acc;
}

/**
 * Ubah status order. force=true untuk koreksi manual (boleh mundur).
 * Mengembalikan order terbaru atau null bila tidak berubah.
 */
async function setStatus(orderId, status, { actor = 'system', detail = null, force = false, extra = {} } = {}) {
  if (!ALL_STATUS.includes(status)) throw new Error('Status tidak dikenal: ' + status);
  const o = await getById(orderId);
  if (!o) throw new Error('Order tidak ditemukan');
  if (!force) {
    if (TERMINAL.includes(o.status) && !TERMINAL.includes(status)) return null;
    if (RANK[status] && RANK[o.status] && RANK[status] <= RANK[o.status]) {
      // status tidak maju; tetap simpan kolom tambahan (mis. waktu selesai)
      if (Object.keys(extra).length) await updateFields(orderId, extra);
      return null;
    }
  }
  await updateFields(orderId, { ...extra, status });
  await addEvent(orderId, 'STATUS', { from: o.status, to: status, ...(detail ? { info: detail } : {}) }, actor);
  const updated = await getById(orderId);
  bus.emit('order.status', updated, o.status);
  if (TERMINAL.includes(status)) bus.emit('order.cancelled', updated);
  return updated;
}

const UPDATABLE = new Set([
  'modality', 'station_ae', 'scheduled_at', 'priority', 'status', 'mpps_uid', 'exam_started_at', 'exam_ended_at',
  'radiographer', 'pacs_study_id', 'images_count', 'images_at', 'khanza_tgl_periksa', 'khanza_jam',
  'khanza_written_at', 'hl7_sent_at', 'ss_servicerequest_id', 'ss_imagingstudy_id', 'ss_observation_id',
  'ss_diagnosticreport_id', 'ss_dicom_forwarded_at', 'ss_error', 'clinical_info', 'diagnosis',
]);

async function updateFields(orderId, fields) {
  const keys = Object.keys(fields).filter((k) => UPDATABLE.has(k));
  if (!keys.length) return;
  await db.risQuery(
    `UPDATE ris_orders SET ${keys.map((k) => `\`${k}\`=?`).join(', ')} WHERE id=?`,
    [...keys.map((k) => fields[k]), orderId]
  );
}

async function listOrders({ dateFrom, dateTo, status, modality, q, limit = 300 } = {}) {
  const where = [];
  const p = [];
  if (dateFrom) { where.push('o.scheduled_at >= ?'); p.push(dateFrom + ' 00:00:00'); }
  if (dateTo) { where.push('o.scheduled_at <= ?'); p.push(dateTo + ' 23:59:59'); }
  if (status) {
    const st = String(status).split(',').filter((s) => ALL_STATUS.includes(s));
    if (st.length) { where.push(`o.status IN (${st.map(() => '?').join(',')})`); p.push(...st); }
  }
  if (modality) { where.push('o.modality = ?'); p.push(modality); }
  if (q) {
    where.push('(o.patient_name LIKE ? OR o.no_rkm_medis LIKE ? OR o.accession_number LIKE ? OR o.noorder LIKE ? OR o.no_rawat LIKE ?)');
    const like = `%${q}%`;
    p.push(like, like, like, like, like);
  }
  return db.risQuery(
    `SELECT o.*, r.status AS report_status, r.radiologist_name
       FROM ris_orders o LEFT JOIN ris_reports r ON r.order_id = o.id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY (o.priority='STAT') DESC, o.scheduled_at DESC LIMIT ${Math.min(+limit || 300, 1000)}`,
    p
  );
}

module.exports = {
  bus, RANK, ALL_STATUS, addEvent, getById, getByAccession, getByStudyUid, nextAccession, setStatus,
  updateFields, listOrders,
};
