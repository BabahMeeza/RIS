'use strict';
const path = require('path');
const express = require('express');
const config = require('./config');
const log = require('./lib/logger')('ris');
const db = require('./lib/db');

const sync = require('./services/orderSync');
const reportService = require('./services/reportService');
const scp = require('./dicom/scp');
const hl7 = require('./hl7/hl7Service');
const orthanc = require('./pacs/orthanc');
const satusehat = require('./satusehat/satusehatService');

async function main() {
  await db.risQuery('SELECT 1').catch((e) => {
    log.error(`Tidak dapat terhubung ke database RIS ${config.risDb.host}/${config.risDb.database}`, e);
    process.exit(1);
  });

  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '2mb' }));
  app.use('/api', require('./routes/api'));
  app.use(express.static(path.join(__dirname, '..', 'public')));
  app.listen(config.http.port, () => log.info(`Web RIS ${config.hospital.name}: http://0.0.0.0:${config.http.port}`));

  hl7.injectReportService(reportService);
  sync.start();
  if (config.dicom.enabled) await scp.start();
  if (config.hl7.enabled) hl7.start({ reportService });
  if (config.orthanc.enabled) orthanc.start();
  if (config.satusehat.enabled) satusehat.start();
}

process.on('unhandledRejection', (e) => log.error('Unhandled rejection', e));
main();
